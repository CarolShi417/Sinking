extends Node
# resing, working, dead状态下两个worker的显示与隐藏

#@onready var worker_rest = get_tree().get_first_node_in_group("WorkerResting")
@onready var worker = get_tree().get_first_node_in_group("WorkerWorking")

const REST_POSITION := Vector2(450, 190)
const WORK_POSITION := Vector2(1400, 225)

func _ready():
	GameState.state_changed.connect(_on_state_changed)
	
	worker.z_index = 40
	worker.position = REST_POSITION
	print("worker.position = ", worker.position)

	if GameState.current_state == DataTypes.GameState.Resting:
		_show_rest_worker()


func _on_state_changed(state):
	if state == DataTypes.GameState.Resting:
		_show_rest_worker()
	elif state == DataTypes.GameState.Working:
		_show_work_worker()
	elif state == DataTypes.GameState.Dead:
		_worker_dead()


func _show_rest_worker() -> void:
	await get_tree().create_timer(1.5).timeout
	worker.show()
	worker.position = REST_POSITION
	worker.reset_movement(1)
	worker.LEFT_LIMIT = 10
	worker.RIGHT_LIMIT = 900


func _show_work_worker() -> void:
	await get_tree().create_timer(1.5).timeout
	worker.show()
	worker.position = WORK_POSITION
	worker.reset_movement(-1)
	worker.LEFT_LIMIT = 1000
	worker.RIGHT_LIMIT = 1900


func _worker_dead() -> void:
	await get_tree().create_timer(2.0).timeout
	worker.show()
	worker.position = REST_POSITION
	worker.reset_movement(1)
	
