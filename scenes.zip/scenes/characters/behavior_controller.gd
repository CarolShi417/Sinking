extends Node

@onready var state_machine: Node = $"../StateMachine"
@onready var worker_work = get_tree().get_first_node_in_group("WorkerWorking")

signal dead_flow_finished #向state发送死亡流程结束信号，让state切换为dead

var behavior_timer: Timer
var current_behavior : DataTypes.BehaviorState
var dead_flow_running := false # 确保死亡状态不要重复执行

var scare_flow_running = false # 防止 hover 抖动导致流程重复触发

var flow_running := false  # 防止send_and_receive_flow()协程堆积

# ===============================
# 各Behavior持续时间
# ===============================
# rest
const rest_idle_duration := 5.0
const rest_walk_duration := 5.0
# work
const work_idle_duration := 5.0
const work_walk_duration := 5.0
const work_gather_duration := 10.0
# dead and alive
const dying_duration := 2.0
const dead_rest_duration := 300.0
const alive_rest_duration := 0.5
# scare
const scare_duration := 2.0
const scare_gather_duration := 2.0

# ===============================
# 悬停判定是否切换state，供 scare - gather
# ===============================
var _is_hovering := false

#音效
@onready var is_assigned_sfx: AudioStreamPlayer2D = $"../AudioStreamPlayer_isAssignedSFX"
@onready var walk_sfx: AudioStreamPlayer2D = $"../AudioStreamPlayer_walkSFX"

func _ready() -> void:
	GameState.state_changed.connect(_on_state_changed)
	GameState.behavior_changed.connect(_on_behavior_changed)
	_create_behavior_timers()#
	if GameState.current_state == DataTypes.GameState.Resting:
		start_idle_timer()
		
	# 鼠标hover在worker上时，为动画做准备
	HoverController.hover_changed.connect(_on_hover_changed)
	
	#随机石子事件	
	worker_work.stone_walk_started.connect(_on_stone_walk_started)
	worker_work.stone_walk_finished.connect(_on_stone_walk_finished)

#创建行为计时器
func _create_behavior_timers():
	behavior_timer = Timer.new()
	behavior_timer.one_shot = true
	behavior_timer.timeout.connect(_on_behavior_timeout)# Timer 结束时调用

	
	add_child(behavior_timer)
	
	
	
# ===============================
# 死亡时，状态有所不同
# ===============================
func _on_state_changed(state):	
	#停止行为计时器
	behavior_timer.stop()
	#确保当前状态为死亡状态
	if state != DataTypes.GameState.Dead:
		dead_flow_running = false
		
	match state:
		
		DataTypes.GameState.Resting:
			send_and_receive_flow()			

		DataTypes.GameState.Working:
			send_and_receive_flow()			

		DataTypes.GameState.Dead:
			flow_running = false  # 👈 死亡时强制重置
			if dead_flow_running:
				return
			
			dead_flow_running = true
			_start_dead_flow()

# ===============================			
# 派遣-接收动画
# ===============================
func send_and_receive_flow():	
	if flow_running:  # 👈 已有flow在跑，直接return
		return
	flow_running = true
	
	# 行为状态为 派遣
	print(">>> flow START, state=", GameState.current_state)
	current_behavior = DataTypes.BehaviorState.send
	GameState.set_behavior(current_behavior)
	print(current_behavior)
	# 等待动画播放完成
	await get_tree().create_timer(1.5).timeout
	
	print(">>> flow after first await, state=", GameState.current_state)
	current_behavior = DataTypes.BehaviorState.receive
	GameState.set_behavior(current_behavior)
	print(current_behavior)
	# 等待动画播放完成
	await get_tree().create_timer(1.5).timeout
	
	print(">>> flow END, state=", GameState.current_state)
	start_idle_timer()
	
# ===============================
# 切换worker状态，连接不同动画
# ===============================
func _on_behavior_changed(new_behavior):
	# 只要不是 walk，就停止走路音效
	if new_behavior != DataTypes.BehaviorState.walk:
		walk_sfx.stop()
		
	match new_behavior:
		DataTypes.BehaviorState.idle:
			state_machine.transition_to("Idle")

		DataTypes.BehaviorState.walk:
			state_machine.transition_to("Walk")
			walk_sfx.play()

		DataTypes.BehaviorState.gather:
			state_machine.transition_to("Gather")
		
		DataTypes.BehaviorState.dying:
			state_machine.transition_to("Dying")
		
		DataTypes.BehaviorState.dead_rest:
			state_machine.transition_to("Dead_rest")
			
		DataTypes.BehaviorState.alive_rest:
			state_machine.transition_to("Alive_rest")
		
		DataTypes.BehaviorState.send:
			state_machine.transition_to("Send")
			is_assigned_sfx.play()

		DataTypes.BehaviorState.receive:
			state_machine.transition_to("Receive")
			
		DataTypes.BehaviorState.scare:
			state_machine.transition_to("Scare")
		
		
# =====================
# 开始behavior计时
# =====================
func start_idle_timer():
	current_behavior = DataTypes.BehaviorState.idle
	GameState.set_behavior(current_behavior)

	var duration

	if GameState.current_state == DataTypes.GameState.Resting:
		duration = rest_idle_duration
	else:
		duration = work_idle_duration

	#print("idle duration:", duration)

	behavior_timer.start(duration)
	

func start_walk_timer():

	current_behavior = DataTypes.BehaviorState.walk
	GameState.set_behavior(current_behavior)

	var duration

	if GameState.current_state == DataTypes.GameState.Resting:
		duration = rest_walk_duration
	else:
		duration = work_walk_duration

	#print("walk duration:", duration)

	behavior_timer.start(duration)


func start_gather_timer():

	current_behavior = DataTypes.BehaviorState.gather
	GameState.set_behavior(current_behavior)

	#print("gather duration:", work_gather_duration)

	behavior_timer.start(work_gather_duration)
	
# =====================
# Timer结束
# =====================
func _on_behavior_timeout():

	match GameState.current_state:

		DataTypes.GameState.Resting:
			_rest_cycle()

		DataTypes.GameState.Working:
			_work_cycle()

# =====================
# Resting循环
# =====================

func _rest_cycle():

	match current_behavior:

		DataTypes.BehaviorState.idle:
			start_walk_timer()

		DataTypes.BehaviorState.walk:
			start_idle_timer()

# =====================
# Working循环
# =====================
func _work_cycle():

	match current_behavior:

		DataTypes.BehaviorState.idle:
			start_gather_timer()

		DataTypes.BehaviorState.gather:
			start_walk_timer()

		DataTypes.BehaviorState.walk:
			start_idle_timer()

# =====================
# 死亡状态
# =====================		
func _start_dead_flow():

	# 1. dying（2秒）
	current_behavior = DataTypes.BehaviorState.dying
	GameState.set_behavior(current_behavior)
	await get_tree().create_timer(dying_duration).timeout
	if not dead_flow_running:
		return
		
	# 2. dead_rest（5分钟）
	current_behavior = DataTypes.BehaviorState.dead_rest
	GameState.set_behavior(current_behavior)
	await get_tree().create_timer(dead_rest_duration).timeout
	if not dead_flow_running:
		return
		
	# 3. alive_rest（0.5秒）
	current_behavior = DataTypes.BehaviorState.alive_rest
	GameState.set_behavior(current_behavior)
	await get_tree().create_timer(alive_rest_duration).timeout
	if not dead_flow_running:
		return
		
	# 4. 回到Resting状态
	if GameState.current_state == DataTypes.GameState.Dead:
		dead_flow_finished.emit()

# =====================
# 惊吓状态（悬停时触发）
# =====================	
func _on_hover_changed(is_hovering: bool) -> void:
	# dead， send，receive状态下不触发
	if GameState.current_state == DataTypes.GameState.Dead:
		return
	if current_behavior == DataTypes.BehaviorState.send or current_behavior == DataTypes.BehaviorState.receive:
		return
		
	_is_hovering = is_hovering
	
	# 其他状态下，触发
	if is_hovering and not scare_flow_running:
		start_scare_flow()
	elif not is_hovering and scare_flow_running:
		# hover 离开，打断 gather 循环
		scare_flow_running = false
		start_idle_timer()
		
func start_scare_flow() -> void:
	scare_flow_running = true;
	behavior_timer.stop()
	
	# 1. Scare（2秒）
	GameState.set_behavior(DataTypes.BehaviorState.scare)
	await get_tree().create_timer(scare_duration).timeout
	if not scare_flow_running:
		return
 
	# 2. Gather，持续保持直到 hover 离开
	current_behavior = DataTypes.BehaviorState.gather
	GameState.set_behavior(current_behavior)
	while scare_flow_running and _is_hovering:
		await get_tree().process_frame
 
	# 3. hover 已离开，重新开始计时循环
	scare_flow_running = false
	start_idle_timer()

# =====================
# 随机石子事件
# =====================
func _on_stone_walk_started() -> void:
	if GameState.current_state == DataTypes.GameState.Dead:
		return
	if current_behavior == DataTypes.BehaviorState.send or \
		current_behavior == DataTypes.BehaviorState.receive:
		return
	# 打断当前循环，切为 idle
	behavior_timer.stop()
	scare_flow_running = false
	current_behavior = DataTypes.BehaviorState.walk
	GameState.set_behavior(current_behavior)

func _on_stone_walk_finished() -> void:
	if GameState.current_state == DataTypes.GameState.Dead:
		return
	
	# 到达后也保持 idle，等石子拾取逻辑结束后再 start_idle_timer()
	current_behavior = DataTypes.BehaviorState.idle
	GameState.set_behavior(current_behavior)
	await get_tree().create_timer(3.0).timeout #后面插入gather动画
	
	# 重启正常循环
	start_idle_timer()
